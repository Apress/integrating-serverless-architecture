﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterBot.Web.Configuration
{
    public class AppSettingsConfiguration
    {
        public AppSettings AppSettings { get; set; }
    }
}
