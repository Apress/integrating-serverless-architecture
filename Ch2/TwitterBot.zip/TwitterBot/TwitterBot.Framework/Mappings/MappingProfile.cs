﻿using AutoMapper;

namespace TwitterBot.Framework.Mappings
{
    public class MappingProfile : Profile
    {
        public static void Activate()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.CreateMap<Tweetinvi.Models.ITweet, Types.Tweet>();
            });
        }
    }
}
