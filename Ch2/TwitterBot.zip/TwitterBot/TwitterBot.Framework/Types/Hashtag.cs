﻿namespace TwitterBot.Framework.Types
{
    public class Hashtag : BaseType
    {
        public string Text { get; set; }
    }
}
