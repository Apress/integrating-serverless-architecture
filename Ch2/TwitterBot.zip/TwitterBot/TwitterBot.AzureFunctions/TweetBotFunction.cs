using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.BusinessLogic;
using TwitterBot.Framework.Mappings;
using TwitterBot.Framework.Types;

namespace TwitterBot.AzureFunctions
{
    public static class TweetBotFunction
    {
        [FunctionName("TweetBotFunction")]
        public static void Run([TimerTrigger("0 */5 * * * *")]TimerInfo myTimer, ILogger log, [Inject]ITweetOperations tweetOperations)
        {
            var tweet = tweetOperations.GetPopularTweetByHashtag(new Hashtag { Text = "#justsaying" });
            if (tweet != null)
            {
                log.LogInformation($"Latest popular tweet for #justsaying : { tweet.FullText }");
            }
        }
    }
}
