﻿using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.Extensions.DependencyInjection;
using TwitterBot.AzureFunctions;
using TwitterBot.Framework.BusinessLogic;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Mappings;

[assembly: WebJobsStartup(typeof(WebJobsExtensionStartup), "TwitterBot Extensions Startup")]
namespace TwitterBot.AzureFunctions
{
    public class WebJobsExtensionStartup : IWebJobsStartup
    {
        public void Configure(IWebJobsBuilder builder)
        {
            MappingProfile.Activate();
            builder.Services.AddSingleton<ITweetOperations>(new TweetOperations("umUgpc6eOVhGY5hROqN8HKxa9", "95eDHKsKcOxKvWbHqOdAso6GstdRzNq6AiWyRVR7qSayixQqWQ"));
            builder.Services.AddSingleton<InjectBindingProvider>();
            builder.AddExtension<InjectConfiguration>();
        }
    }
}
