using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TwitterBot.Web.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using AspNetCore.Identity.DocumentDb;
using TwitterBot.Web.Identity;


namespace TwitterBot.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<TwitterBot.Web.Configuration.AppSettingsConfiguration>(Configuration);
            var databaseName = "TwitterBotDB";
            var identityCollectionName = "AptNetIdentity";
            var serializationSettings = new JsonSerializerSettings();
            serializationSettings.Converters.Add(new JsonClaimConverter());

            var documentClient = new DocumentClient(
                new Uri(Configuration["TwitterBotDbUri"]),
                Configuration["TwitterBotDbAuthKey"],
                serializationSettings);

            services.AddSingleton<IDocumentClient>(documentClient);
            Task.Run(async () => await InitializeDatabaseAsync(documentClient, databaseName)).Wait();
            Task.Run(async () => await InitializeCollectionAsync(documentClient, databaseName, identityCollectionName)).Wait();

            services.AddIdentity<ApplicationUser, DocumentDbIdentityRole>()
                .AddDocumentDbStores(options =>
                {
                    options.UserStoreDocumentCollection = identityCollectionName;
                    options.Database = databaseName;
                });

            services.ConfigureApplicationCookie(options => options.LoginPath = "/");

            services.AddAuthentication().AddTwitter(twitterOptions =>
            {
                twitterOptions.ConsumerKey = Configuration["TwitterAPIKey"];
                twitterOptions.ConsumerSecret = Configuration["TwitterAPISecret"];
            });

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
                .AddRazorPagesOptions(options =>
                {
                    options.Conventions.AuthorizeFolder("/Tweet");
                });
            ;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseCookiePolicy();

            app.UseAuthentication();

            app.UseMvc();
        }

        private async Task InitializeDatabaseAsync(DocumentClient documentClient, string databaseName)
        {
            await documentClient.CreateDatabaseIfNotExistsAsync(new Database { Id = databaseName });
        }

        private async Task InitializeCollectionAsync(DocumentClient documentClient, string databaseName, string collectionName)
        {
            DocumentCollection collection = new DocumentCollection() { Id = collectionName };
            collection = await documentClient.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(databaseName), collection);
        }
    }
}
