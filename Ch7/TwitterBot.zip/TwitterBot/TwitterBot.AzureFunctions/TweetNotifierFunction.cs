using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.SignalRService;
using Microsoft.Extensions.Logging;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.DependencyInjection;

namespace TwitterBot.AzureFunctions
{
    public static class TweetNotifierFunction
    {
        [FunctionName("TweetNotifierFunction")]
        public static async Task Run([CosmosDBTrigger(
            databaseName: "TwitterBotDB",
            collectionName: "TweetCollection",
            ConnectionStringSetting = "TwitterBotDbConnectionString",
            LeaseCollectionName = "leases",
            CreateLeaseCollectionIfNotExists = true)]IReadOnlyList<Document> documents,
            [SignalR(HubName = "TweetNotificationsHub")]IAsyncCollector<SignalRMessage> messages,
            [Inject]IDocumentDbRepository<Framework.Types.User> userRepository,
            [Inject]IDocumentDbRepository<Framework.Types.Tweet> tweetRepository,
            ILogger log)
        {
            log.LogInformation("Documents modified " + documents.Count);

            foreach (var document in documents)
            {
                var tweet = await tweetRepository.GetByIdAsync(document.Id);
                var users = userRepository.GetUsersByHashtags(tweet.Hashtags.Select(p => p.Text).ToArray());
                foreach (var user in users)
                {
                    await messages.AddAsync(new SignalRMessage
                    {
                        UserId = user.Id,
                        Target = "updateTweets",
                        Arguments = new[] { tweet }
                    });
                }
            }

           await messages.FlushAsync();
        }
    }
}
