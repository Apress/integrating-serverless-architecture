using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using TwitterBot.Framework.Types;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.DependencyInjection;
using System.Linq;
using System.Collections.Generic;

namespace TwitterBot.AzureFunctions.Http
{
    public static class SaveUserPreferences
    {
        [FunctionName("SaveUserPreferences")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = null)] HttpRequest req,
            [Inject]IDocumentDbRepository<User> userRepository,
            [Inject]IDocumentDbRepository<Hashtag> hashtagRepository,
            ILogger log)
        {
            log.LogInformation("SaveUserPreferences started.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var user = JsonConvert.DeserializeObject<User>(requestBody);

            // Add/Update Hashtag
            var hashtags = user.Hashtags != null ? user.Hashtags.Select(p => p.Text).ToList() : new List<string>();
            var dbHashtagQuery = await hashtagRepository.WhereAsync(p => hashtags.Contains(p.Text));
            var dbHashtags = dbHashtagQuery.ToList();

            foreach (var hashtag in user.Hashtags)
            {
                if (dbHashtags.Any(p => p.Text == hashtag.Text))
                {
                    continue;
                }

                hashtag.IsCurrentlyInQueue = false;
                hashtag.LastSyncedDateTime = DateTime.UtcNow.AddMinutes(-10);
                await hashtagRepository.AddOrUpdateAsync(hashtag);
            }

            // Add/Update User
            var dbuserQuery = await userRepository.WhereAsync(p => p.UserId == user.UserId);
            var users = dbuserQuery.ToList();

            if (users != null && users.Count() != 0)
            {
                user.Id = users.FirstOrDefault().Id;
            }

            await userRepository.AddOrUpdateAsync(user);

            log.LogInformation("SaveUserPreferences completed.");

            return new OkResult();
        }
    }
}
