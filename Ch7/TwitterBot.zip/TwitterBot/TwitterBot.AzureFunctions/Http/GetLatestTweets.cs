using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Types;
using System.Linq;
using System;

namespace TwitterBot.AzureFunctions.Http
{
    public static class GetLatestTweets
    {
        [FunctionName("GetLatestTweets")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequest req,
            [Inject]IDocumentDbRepository<User> userRepository,
            [Inject]IDocumentDbRepository<Tweet> tweetRepository,
            ILogger log)
        {
            log.LogInformation("GetLatestTweets started.");

            string userId = req.Query["uid"];
            var dbUsers = await userRepository.TopAsync(p => p.UserId == userId, 1);
            if (dbUsers == null || dbUsers.Count() == 0)
            {
                return new JsonResult(null);
            }

            var user = dbUsers.ToList().FirstOrDefault(p => p.UserId == userId);
            if (user.Hashtags == null || user.Hashtags.Count == 0)
            {
                return new JsonResult(null);
            }
            var tweets = tweetRepository.GetTweetsByHashtags(user.Hashtags.Select(p => p.Text).ToArray(), DateTime.UtcNow.AddDays(-2));
            if(tweets != null)
            {
                tweets = tweets.OrderByDescending(p => p.TweetCreatedOn);
            }

            log.LogInformation("GetLatestTweets completed.");
            return new JsonResult(tweets);
        }
    }
}

