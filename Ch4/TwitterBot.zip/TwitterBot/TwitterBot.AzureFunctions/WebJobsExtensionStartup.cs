﻿using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using TwitterBot.AzureFunctions;
using TwitterBot.Framework.BusinessLogic;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.Contracts.ServiceBus;
using TwitterBot.Framework.CosmosDB;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Mappings;
using TwitterBot.Framework.ServiceBus;

[assembly: WebJobsStartup(typeof(WebJobsExtensionStartup), "TwitterBot Extensions Startup")]
namespace TwitterBot.AzureFunctions
{
    public class WebJobsExtensionStartup : IWebJobsStartup
    {
        public void Configure(IWebJobsBuilder builder)
        {
            MappingProfile.Activate();

            // CosmosDB Configuration
            var documentDbContext = new DocumentDbContext
            {
                AuthKey = "ZYjTaqxYaeseSTUubuZcqC4pUXcn50AuczCrmHN9RsKYick1iVMoAv38UkMJTN4xYRkPEY0MTpt2fbWbiCEAwQ==",
                DatabaseId = "TwitterBotDB",
                EndpointUri = "https://twitterbotdb.documents.azure.com:443/"
            };
            Task.Run(async () => await documentDbContext.CreateDatabaseAndCollectionsAsync()).Wait();
            builder.Services.AddSingleton<IDocumentDbContext>(documentDbContext);
            builder.Services.AddSingleton(typeof(IDocumentDbRepository<>), typeof(DocumentDbRepository<>));

            // Service Bus Configuration
            var serviceBusContext = new ServiceBusContext()
            {
                ConnectionString = "Endpoint=sb://twitterbotservicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=ZwbhP4oK+ELnDjZ0kqIIrQU8oYaZ7+TbcNRWz9n48xY=",
                QueueName = "HashTagQueue",
                MaxConcurrentMessagesToBeRetrieved = 2,
                SessionId = "TwitterBotApplication",
                OperationTimeout = TimeSpan.FromMilliseconds(500)
            };
            builder.Services.AddSingleton<IServiceBusContext>(serviceBusContext);
            builder.Services.AddSingleton<IServiceBusOperations>(new ServiceBusOperations(serviceBusContext));
            
            builder.Services.AddSingleton<ITweetOperations>(new TweetOperations("umUgpc6eOVhGY5hROqN8HKxa9", "95eDHKsKcOxKvWbHqOdAso6GstdRzNq6AiWyRVR7qSayixQqWQ"));
            builder.Services.AddSingleton<InjectBindingProvider>();
            builder.AddExtension<InjectConfiguration>();
        }
    }
}
