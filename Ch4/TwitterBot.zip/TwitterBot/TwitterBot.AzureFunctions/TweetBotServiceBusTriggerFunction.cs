using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Types;

namespace TwitterBot.AzureFunctions
{
    public static class TweetBotServiceBusTriggerFunction
    {
        ////[FunctionName("TweetBotServiceBusTriggerFunction")]
        public async static Task Run([ServiceBusTrigger("hashtagqueue", Connection = "TwitterBotServiceBus_ConnectionString")]string myQueueItem,
            ILogger log,
            [Inject]ITweetOperations tweetOperations,
            [Inject]IDocumentDbRepository<Tweet> tweetDbRepository,
            [Inject]IDocumentDbRepository<Hashtag> hashTagRepository)
        {
            var hashtag = JsonConvert.DeserializeObject<Hashtag>(myQueueItem);
            // Retrieve the latest tweet.
            var tweet = tweetOperations.GetPopularTweetByHashtag(hashtag);
            if (tweet != null)
            {
                tweet.Hashtags = new List<Hashtag>();
                log.LogInformation($"Latest popular tweet for {hashtag.Text} : { tweet.FullText }");

                // Check if DB already has the tweet.
                var existingTweet = await tweetDbRepository.GetByIdAsync(tweet.Id);

                // If tweet is not present in DB, then add to DB.
                if (existingTweet == null)
                {
                    tweet.Hashtags.Add(hashtag);
                    // Add the tweet to DB.
                    await tweetDbRepository.AddOrUpdateAsync(tweet);

                    log.LogInformation($"Added Tweet in TweetCollection with Id : { tweet.Id }");
                }

                // Map DB Hashtags with latest Tweet.
                if (existingTweet != null && !existingTweet.Hashtags.Any(p => p.Text == hashtag.Text))
                {
                    // Map the existing hashtags to tweet.
                    tweet.Hashtags = existingTweet.Hashtags;
                    // Add the current hashtag to tweet.
                    tweet.Hashtags.Add(hashtag);
                    // Update the tweet to DB.
                    await tweetDbRepository.AddOrUpdateAsync(tweet);

                    log.LogInformation($"Updated Tweet in TweetCollection with Id : { tweet.Id }");
                }
            }

            // Update the hashtag's Last sync Date time with current time and currently in queue as false.
            hashtag.IsCurrentlyInQueue = false;
            hashtag.LastSyncedDateTime = DateTime.UtcNow;
            await hashTagRepository.AddOrUpdateAsync(hashtag);
        }
    }
}
