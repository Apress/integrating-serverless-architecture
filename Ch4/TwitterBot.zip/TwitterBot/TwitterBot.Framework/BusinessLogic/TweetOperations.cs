﻿using AutoMapper;
using System.Linq;
using Tweetinvi;
using Tweetinvi.Models;
using Tweetinvi.Parameters;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.Types;

namespace TwitterBot.Framework.BusinessLogic
{
    public class TweetOperations : ITweetOperations
    {
        private string _consumerKey;
        private string _consumerSecret;
        public TweetOperations(string consumerKey, string consumerSecret)
        {
            _consumerKey = consumerKey;
            _consumerSecret = consumerSecret;
        }

        public Types.Tweet GetPopularTweetByHashtag(Hashtag hashtag)
        {
            Auth.SetApplicationOnlyCredentials(_consumerKey, _consumerSecret, true);

            ISearchTweetsParameters searchParameter = Search.CreateTweetSearchParameter(hashtag.Text);
            searchParameter.SearchType = SearchResultType.Popular;
            searchParameter.MaximumNumberOfResults = 1;
            var tweet = Search.SearchTweets(searchParameter);

            if (!tweet.Any())
            {
                return null;
            }

            var topTweet = tweet.FirstOrDefault();
            return Mapper.Map<Types.Tweet>(topTweet);
        }
    }
}
