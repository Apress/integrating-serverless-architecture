﻿using System;
using System.Collections.Generic;
using TwitterBot.Framework.Types;
using System.Linq;

namespace TwitterBot.Framework.Exceptions
{
    public class TwitterBotBusinessException : Exception
    {
        public List<Hashtag> Hashtags { get; set; }
        public TwitterBotBusinessException(List<Hashtag> hashtags)
        {
            this.Hashtags = hashtags;
        }

        public override String Message
        {
            get
            {
                return String.Format("Exception Occurred while processing: {0}", String.Join(",", Hashtags.Select(p => p.Text)));
            }
        }
    }
}
