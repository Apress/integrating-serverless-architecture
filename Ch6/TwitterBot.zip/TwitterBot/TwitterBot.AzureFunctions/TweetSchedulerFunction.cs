using System;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.Contracts.ServiceBus;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Types;

namespace TwitterBot.AzureFunctions
{
    public static class TweetSchedulerFunction
    {
        [FunctionName("TweetSchedulerFunction")]
        public async static Task Run([TimerTrigger("0 */1 * * * *")]TimerInfo myTimer, ILogger log,
            [Inject]IServiceBusOperations serviceBusOperations,
            [Inject]IDocumentDbRepository<Hashtag> hashTagRepository)
        {
            log.LogInformation($"TweetSchedulerFunction started execution at: {DateTime.Now}");

            // Get Hashtags from TwitterBot Cosmos DB.
            var hashtags = await hashTagRepository.WhereAsync(p => (!p.IsCurrentlyInQueue && p.LastSyncedDateTime < DateTime.UtcNow.AddMinutes(-10))
            || (p.IsCurrentlyInQueue && p.LastSyncedDateTime < DateTime.UtcNow.AddHours(-1)));

            foreach (var hashtag in hashtags)
            {
                // Queue the hashtags.
                await serviceBusOperations.SendMessageAsync(hashtag.Id, JsonConvert.SerializeObject(hashtag));

                // Mark the hashtags as currently in queue.
                hashtag.IsCurrentlyInQueue = true;
                await hashTagRepository.AddOrUpdateAsync(hashtag);
            }

            log.LogInformation($"TweetSchedulerFunction completed execution at: {DateTime.Now}");
        }
    }
}
