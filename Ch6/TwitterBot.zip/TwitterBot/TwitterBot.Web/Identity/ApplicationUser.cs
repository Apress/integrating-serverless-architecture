﻿using AspNetCore.Identity.DocumentDb;
namespace TwitterBot.Web.Identity
{
    public class ApplicationUser : DocumentDbIdentityUser<DocumentDbIdentityRole>
    { }
}
