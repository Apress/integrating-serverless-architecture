﻿using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.WebJobs.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Threading.Tasks;
using TwitterBot.AzureFunctions;
using TwitterBot.Framework.BusinessLogic;
using TwitterBot.Framework.Configuration;
using TwitterBot.Framework.Contracts;
using TwitterBot.Framework.Contracts.Data;
using TwitterBot.Framework.Contracts.ServiceBus;
using TwitterBot.Framework.CosmosDB;
using TwitterBot.Framework.DependencyInjection;
using TwitterBot.Framework.Exceptions;
using TwitterBot.Framework.Mappings;
using TwitterBot.Framework.ServiceBus;

[assembly: WebJobsStartup(typeof(WebJobsExtensionStartup), "TwitterBot Extensions Startup")]
namespace TwitterBot.AzureFunctions
{
    public class WebJobsExtensionStartup : IWebJobsStartup
    {
        public void Configure(IWebJobsBuilder builder)
        {
            MappingProfile.Activate();

            // Default configuration
            var serviceConfig = builder.Services.FirstOrDefault(s => s.ServiceType.Equals(typeof(IConfiguration)));
            var defaultConfig = (IConfiguration)serviceConfig.ImplementationInstance;

            // Create a new config by merging default with Azure Key Vault configuration.
            string keyvaultName = "TwitterBotKeyVault";
            var config = new ConfigurationBuilder()
                .AddConfiguration(defaultConfig)
                .SetBasePath(Environment.CurrentDirectory)
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddAzureKeyVault($"https://{keyvaultName}.vault.azure.net/").Build();

            // Replace the existing config
            builder.Services.AddSingleton<IConfiguration>(config);
            builder.Services.Configure<AppSettingsConfiguration>(config);

            // CosmosDB Configuration
            var documentDbContext = new DocumentDbContext
            {
                AuthKey = config["TwitterBotDbAuthKey"],
                DatabaseId = "TwitterBotDB",
                EndpointUri = config["TwitterBotDbUri"]
            };
            Task.Run(async () => await documentDbContext.CreateDatabaseAndCollectionsAsync()).Wait();
            builder.Services.AddSingleton<IDocumentDbContext>(documentDbContext);
            builder.Services.AddSingleton(typeof(IDocumentDbRepository<>), typeof(DocumentDbRepository<>));

            // Service Bus Configuration
            var serviceBusContext = new ServiceBusContext()
            {
                ConnectionString = config["TwitterBotServiceBusConnectionString"],
                QueueName = "HashTagQueue",
                MaxConcurrentMessagesToBeRetrieved = 2,
                SessionId = "TwitterBotApplication",
                OperationTimeout = TimeSpan.FromMilliseconds(500)
            };
            builder.Services.AddSingleton<IServiceBusContext>(serviceBusContext);
            builder.Services.AddSingleton<IServiceBusOperations>(new ServiceBusOperations(serviceBusContext));
            
            builder.Services.AddSingleton<ITweetOperations>(new TweetOperations(config["TwitterAPIKey"], config["TwitterAPISecret"]));
            builder.Services.AddSingleton<InjectBindingProvider>();
            builder.AddExtension<InjectConfiguration>();

            // Exception Filter
            builder.Services.AddSingleton<IFunctionFilter, TwitterBotBusinessExceptionFilter>();
        }
    }
}
