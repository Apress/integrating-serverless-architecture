﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterBot.Framework.Configuration
{
    public class AppSettings
    {
        public int TweetsFilterIntervalInDays { get; set; }
        public int HashtagSyncIntervalInMinutes { get; set; }
        public int HashtagQueueThresholdIntervalInHours { get; set; }
    }
}

