﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterBot.Web.Configuration
{
    public class AppSettings
    {
        public string ServiceBaseUrl { get; set; }
    }
}

